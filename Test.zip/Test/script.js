document.addEventListener('DOMContentLoaded', () => {

    // Submit form for URL input
    document.getElementById("searchForm").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent default form submission

        const urlInput = document.getElementById("urlInput").value.trim();
        console.log("URL Input:", urlInput);

        // Validate inputs
        if (!validateInputs()) return;

        const formData = new FormData();
        formData.append("url", urlInput);

        fetch("your-server-endpoint", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("Server Response:", data);
                document.getElementById("output").textContent = JSON.stringify(data, null, 2);
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    });

    // MongoDB query handling for tool by MPN
    const fetchToolButton = document.getElementById('fetch-tool');
    const mpnInput = document.getElementById('mpn');
    const outputDiv = document.getElementById('output');

    // Event listener for fetching tool by MPN
    fetchToolButton.addEventListener("click", async (event) => {
        event.preventDefault(); // Prevent default form submission
        const mpn = mpnInput.value.trim();

        if (!mpn) {
            displayOutput('Please enter an MPN');
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/search?MPN=${mpn}`); // Backend endpoint
            if (response.ok) {
                const tool = await response.json();
                displayOutput(tool); // Display tool data
            } else {
                displayOutput('Tool not found1');
            }
        } catch (err) {
            displayOutput('Error fetching tool1');
            console.error(err);
        }
    });

    function displayOutput(data) {
        outputDiv.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
    }

    // Drag-and-drop functionality
    document.querySelectorAll(".drop-zone").forEach((dropZoneElement) => {
        const inputElement = dropZoneElement.querySelector(".drop-zone__input");

        dropZoneElement.addEventListener("click", () => {
            inputElement.click();
        });

        inputElement.addEventListener("change", () => {
            console.log("File selected:", inputElement.files[0]?.name || "No file");
            if (inputElement.files.length) {
                updateThumbnail(dropZoneElement, inputElement.files[0]);
            }
        });

        dropZoneElement.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropZoneElement.classList.add("drop-zone--over");
        });

        ["dragleave", "dragend"].forEach((type) => {
            dropZoneElement.addEventListener(type, () => {
                dropZoneElement.classList.remove("drop-zone--over");
            });
        });

        dropZoneElement.addEventListener("drop", (e) => {
            e.preventDefault();
            dropZoneElement.classList.remove("drop-zone--over");

            if (e.dataTransfer.files.length) {
                inputElement.files = e.dataTransfer.files;
                console.log("File dropped:", e.dataTransfer.files[0].name);
                updateThumbnail(dropZoneElement, e.dataTransfer.files[0]);
            }
        });
    });
});

// Thumbnail updates for drag-and-drop
function updateThumbnail(dropZoneElement, file) {
    let thumbnailElement = dropZoneElement.querySelector(".drop-zone__thumb");

    if (!thumbnailElement) {
        thumbnailElement = document.createElement("div");
        thumbnailElement.classList.add("drop-zone__thumb");
        dropZoneElement.appendChild(thumbnailElement);
    }

    thumbnailElement.dataset.label = file.name;

    if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = () => {
            thumbnailElement.style.backgroundImage = `url('${reader.result}')`;
        };
        reader.readAsDataURL(file);
    } else {
        thumbnailElement.style.backgroundImage = null;
    }
}
